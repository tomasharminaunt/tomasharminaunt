const API_KEY = "fc1a1cc7a4d74de1b50fbde982028f99"; 
let currentRecipes = [];
const reviews = {};


function searchRecipes() {
  const ingredients = document.getElementById("ingredient-input").value.trim();

  if (!ingredients) {
    alert("Please enter ingredients.");
    return;
  }

  fetch(`https://api.spoonacular.com/recipes/findByIngredients?ingredients=${ingredients}&number=10&apiKey=${API_KEY}`)
    .then(response => response.json())
    .then(data => {
      currentRecipes = data;
      renderRecipes(currentRecipes);
    })
    .catch(error => console.error("Fetch error:", error));
}


function renderRecipes(recipes) {
  const results = document.getElementById("recipe-results");
  results.innerHTML = "";

  recipes.forEach(recipe => {
    const div = document.createElement("div");
    div.innerHTML = `
      <h3>${recipe.title}</h3>
      <img src="${recipe.image}" width="200">
      <button onclick="getRecipeDetails(${recipe.id})">View Details</button>
    `;
    results.appendChild(div);
  });
}


function getRecipeDetails(id) {
  fetch(`https://api.spoonacular.com/recipes/${id}/information?apiKey=${API_KEY}`)
    .then(res => res.json())
    .then(data => showRecipeDetails(data))
    .catch(err => console.error("Detail fetch error:", err));
}


function showRecipeDetails(recipe) {
  const results = document.getElementById("recipe-results");
  results.innerHTML = `
    <h2>${recipe.title}</h2>
    <img src="${recipe.image}" width="300">
    <p><strong>Instructions:</strong> ${recipe.instructions || "No instructions provided."}</p>
    <div>
      <h3>User Reviews</h3>
      <div id="reviews-section"></div>
      <textarea id="review-text" placeholder="Write your review"></textarea>
      <button id="submit-review-btn">Submit Review</button>
    </div>
  `;

 
  const btn = document.getElementById("submit-review-btn");
  btn.addEventListener("click", () => addReview(recipe.title));

  displayReviews(recipe.title);
}


function addReview(recipeTitle) {
  const text = document.getElementById("review-text").value.trim();
  if (text === "") return;

  if (!reviews[recipeTitle]) reviews[recipeTitle] = [];
  reviews[recipeTitle].push(text);

  document.getElementById("review-text").value = "";
  displayReviews(recipeTitle);
}


function displayReviews(recipeTitle) {
  const section = document.getElementById("reviews-section");
  section.innerHTML = "";

  const recipeReviews = reviews[recipeTitle] || [];
  recipeReviews.forEach((r, i) => {
    const p = document.createElement("p");
    p.innerText = 'Review ${i + 1}: ${r}';
    section.appendChild(p);
  });
}


function addManualRecipe() {
  const title = document.getElementById("manual-title").value;
  const steps = document.getElementById("manual-steps").value;
  const img = document.getElementById("manual-img").value;

  if (!title || !steps || !img) {
    alert("Please fill all fields for manual recipe.");
    return;
  }

  const div = document.createElement("div");
  div.innerHTML = `
    <h3>${title}</h3>
    <img src="${img}" width="200">
    <p>${steps}</p>
  `;

  document.getElementById("manual-recipe-list").appendChild(div);
}


function sortResults() {
  const option = document.getElementById("sort-options").value;

  if (option === "simple") {
  currentRecipes.sort((a, b) => a.title.localeCompare(b.title));
} else if (option === "fast") {
  currentRecipes.sort((a, b) => (a.readyInMinutes || 0) - (b.readyInMinutes || 0));
} else if (option === "top-rated") {
  currentRecipes.sort((a, b) => (b.likes || 0) - (a.likes || 0));
}

  renderRecipes(currentRecipes);
}